from rest_framework import serializers

from mvp.models import Driver, Client, Order


class DriverSerializer(serializers.ModelSerializer):
    # last_name = serializers.CharField(max_length=63)
    # first_name = serializers.CharField(max_length=63)
    # car = serializers.CharField(max_length=15)
    # car_number = serializers.CharField(max_length=10)
    # phone_number = serializers.CharField(max_length=13)
    # username = serializers.CharField(max_length=31)
    # password = serializers.CharField(write_only=True)
    class Meta:
        model = Driver
        fields = ('id', 'last_name', 'first_name')

    


class ClientSerializer(serializers.Serializer):
    last_name = serializers.CharField(max_length=63)
    first_name = serializers.CharField(max_length=63)
    nationality = serializers.CharField(max_length=5)
    phone_number = serializers.CharField(max_length=13)
    username = serializers.CharField(max_length=31)
    password = serializers.CharField(write_only=True)

    def create(self, validated_data):
        client = Client.objects.create(**validated_data)
        client.set_password(validated_data['password'])
        client.save()
        return client


class OrderSerializer(serializers.ModelSerializer):
    # driver = DriverSerializer()
    # client = ClientSerializer()

    class Meta:
        model = Order
        fields = ('id', 'driver', 'client', 'status', 'date')

    def to_representation(self, instance):
        response = super().to_representation(instance)
        response['driver'] = DriverSerializer(instance.driver_id).data
        response['client'] = ClientSerializer(instance.client_id).data
        return response

    def create(self, validated_data):
        order = Order.objects.create(**validated_data)
        order.save()
        return order
