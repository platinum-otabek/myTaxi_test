import os

from django.contrib.auth.models import User

from mvp.models import Driver
from mvp.serializers import DriverSerializer, ClientSerializer

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")

import django

django.setup()

from django.test import TestCase, Client as ClientRequest


class TestDriverViews(TestCase):
    def setUp(self):
        self.client = ClientRequest()

    def test_create_driver(self):
        data = {
            'car': 'test_car',
            'car_number': '01H001AA',
            'phone_number': '+998977777777',
            'first_name': 'test_first_name',
            'last_name': 'test_last_name',
            'username': 'test_username_driver',
            'password': 'test'
        }
        response = self.client.post('/api/v1/driver/', data=data)
        data = response.data
        assert data['first_name'] == 'test_first_name'
        assert data['last_name'] == 'test_last_name'
        assert data['username'] == 'test_username_driver'
        assert data['car'] == 'test_car'
        assert data['car_number'] == '01H001AA'
        assert data['phone_number'] == '+998977777777'

    def test_all_drivers(self):
        data = {
            'car': 'test_car',
            'car_number': '01H001AA',
            'phone_number': '+998977777777',
            'first_name': 'test_first_name',
            'last_name': 'test_last_name',
            'username': 'test_username_driver',
            'password': 'test'
        }
        self.client.post('/api/v1/driver/', data=data)

        response = self.client.get('/api/v1/driver/')
        assert response.status_code == 200
        assert len(response.data) == 1
        data = response.data
        assert data[0]['first_name'] == 'test_first_name'
        assert data[0]['last_name'] == 'test_last_name'
        assert data[0]['username'] == 'test_username_driver'
        assert data[0]['car'] == 'test_car'
        assert data[0]['car_number'] == '01H001AA'
        assert data[0]['phone_number'] == '+998977777777'


class TestClientViews(TestCase):
    def setUp(self):
        self.client = ClientRequest()

    def test_create_client(self):
        data = {
            'nationality': 'UZ',
            'phone_number': '+998977777777',
            'first_name': 'test_first_name',
            'last_name': 'test_last_name',
            'username': 'test_username_driver',
            'password': 'test'
        }
        response = self.client.post('/api/v1/client/', data=data)
        data = response.data
        assert data['first_name'] == 'test_first_name'
        assert data['last_name'] == 'test_last_name'
        assert data['username'] == 'test_username_driver'
        assert data['nationality'] == 'UZ'
        assert data['phone_number'] == '+998977777777'

    def test_all_clients(self):
        data = {
            'nationality': 'UZ',
            'phone_number': '+998977777777',
            'first_name': 'test_first_name',
            'last_name': 'test_last_name',
            'username': 'test_username_driver',
            'password': 'test'
        }
        self.client.post('/api/v1/client/', data=data)

        response = self.client.get('/api/v1/client/')
        assert response.status_code == 200
        assert len(response.data) == 1
        data = response.data
        assert data[0]['first_name'] == 'test_first_name'
        assert data[0]['last_name'] == 'test_last_name'
        assert data[0]['username'] == 'test_username_driver'
        assert data[0]['nationality'] == 'UZ'
        assert data[0]['phone_number'] == '+998977777777'


class TestOrderViews(TestCase):
    def setUp(self):
        self.client = ClientRequest()

    def test_create_order(self):
        # create client
        data_client = {
            'nationality': 'UZ',
            'phone_number': '+998977777777',
            'first_name': 'test_first_name',
            'last_name': 'test_last_name',
            'username': 'test_username_client',
            'password': 'test'
        }
        response_client = self.client.post('/api/v1/client/', data=data_client)
        user_client = User.objects.get(username=response_client.data['username'])

        # create driver
        data_driver = {
            'car': 'test_car',
            'car_number': '01H001AA',
            'phone_number': '+998977777777',
            'first_name': 'test_first_name',
            'last_name': 'test_last_name',
            'username': 'test_username_driver',
            'password': 'test'
        }
        response_driver = self.client.post('/api/v1/driver/', data=data_driver)
        user_driver = User.objects.get(username=response_driver.data['username'])
        driver = Driver.objects.get(user_ptr_id=user_driver.id)

        data_order = {
            'driver_id': DriverSerializer(driver),
            'client_id': user_client.id
        }
        print(f'{data_order}')
        response_order = self.client.post('/api/v1/orders/', data=data_order)
        print(response_order.status_code)
        # assert response_order.status_code == 201
        print(response_order.data)
        # assert data['first_name'] == 'test_first_name'
        # assert data['last_name'] == 'test_last_name'
        # assert data['username'] == 'test_username_driver'
        # assert data['nationality'] == 'UZ'
        # assert data['phone_number'] == '+998977777777'

    # def test_all_clients(self):
    #     data = {
    #         'nationality': 'UZ',
    #         'phone_number': '+998977777777',
    #         'first_name': 'test_first_name',
    #         'last_name': 'test_last_name',
    #         'username': 'test_username_driver',
    #         'password': 'test'
    #     }
    #     self.client.post('/api/v1/client/', data=data)
    #
    #     response = self.client.get('/api/v1/client/')
    #     assert response.status_code == 200
    #     assert len(response.data) == 1
    #     data = response.data
    #     assert data[0]['first_name'] == 'test_first_name'
    #     assert data[0]['last_name'] == 'test_last_name'
    #     assert data[0]['username'] == 'test_username_driver'
    #     assert data[0]['nationality'] == 'UZ'
    #     assert data[0]['phone_number'] == '+998977777777'
